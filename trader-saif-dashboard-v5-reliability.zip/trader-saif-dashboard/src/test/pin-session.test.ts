import { describe, expect, it, vi } from "vitest";

const stored = vi.hoisted(() => ({ pin_hash: "" }));
vi.mock("@/integrations/supabase/client.server", () => ({
  supabaseAdmin: {
    from: () => ({
      select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: stored }) }) }),
    }),
  },
}));

import { isPinAuthorized, unlockPin } from "@/lib/drx.server";

describe("PIN unlock and subsequent request", () => {
  it("authorizes the next tick with the cookie returned by a verified PIN", async () => {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("624817"));
    stored.pin_hash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join("");
    const cookie = await unlockPin("624817", true);
    expect(cookie).toContain("SameSite=None; Secure; Partitioned");
    expect(await isPinAuthorized(new Request("https://dashboard.example/api/public/tick", {
      headers: { cookie: cookie.split(";")[0] ?? "" },
    }))).toBe(true);
    expect(await isPinAuthorized(new Request("https://dashboard.example/api/public/tick"))).toBe(false);
  });
});