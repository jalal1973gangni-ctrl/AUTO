import { describe, expect, it } from "vitest";
import {
  matchSignal,
  nextPeriod,
  numberToSide,
  parseSignalText,
  stepAmount,
  buildSteps,
  pinCookieAttributes,
  canPlaceSignalBet,
} from "@/lib/engine-logic";
import { md5 } from "@/lib/md5";

describe("md5 signing", () => {
  it("matches known RFC 1321 vectors", () => {
    expect(md5("")).toBe("d41d8cd98f00b204e9800998ecf8427e");
    expect(md5("abc")).toBe("900150983cd24fb0d6963f7d28e17f72");
    expect(md5("The quick brown fox jumps over the lazy dog")).toBe(
      "9e107d9d372bb6826bd81d3542a419d6",
    );
  });
});

describe("future signal parsing — any format, last 3 digits only", () => {
  it("parses dash separated pairs", () => {
    const { signals, errors } = parseSignalText("333-BIG, 334-SMALL\n335-big");
    expect(signals).toEqual([
      { key: "333", prediction: "BIG" },
      { key: "334", prediction: "SMALL" },
      { key: "335", prediction: "BIG" },
    ]);
    expect(errors).toEqual([]);
  });

  it("parses space separated, shorthand and side-first layouts", () => {
    const { signals, errors } = parseSignalText(
      "333 BIG\n334 s\nB 335\nSMALL 336",
    );
    expect(signals).toEqual([
      { key: "333", prediction: "BIG" },
      { key: "334", prediction: "SMALL" },
      { key: "335", prediction: "BIG" },
      { key: "336", prediction: "SMALL" },
    ]);
    expect(errors).toEqual([]);
  });

  it("keeps only the last 3 digits of a full period number", () => {
    const { signals, errors } = parseSignalText(
      "20261002100051333 BIG, 20261002100052055 small",
    );
    expect(signals).toEqual([
      { key: "333", prediction: "BIG" },
      { key: "055", prediction: "SMALL" },
    ]);
    expect(errors).toEqual([]);
  });

  it("parses joined and Bangla layouts", () => {
    const { signals, errors } = parseSignalText("333B 334s 335-বড় 336-ছোট");
    expect(signals).toEqual([
      { key: "333", prediction: "BIG" },
      { key: "334", prediction: "SMALL" },
      { key: "335", prediction: "BIG" },
      { key: "336", prediction: "SMALL" },
    ]);
    expect(errors).toEqual([]);
  });

  it("later duplicate for the same last 3 digits overrides the earlier one", () => {
    const { signals } = parseSignalText("333-BIG, 333-SMALL");
    expect(signals).toEqual([{ key: "333", prediction: "SMALL" }]);
  });

  it("reports junk tokens as errors without dropping the good ones", () => {
    const { signals, errors } = parseSignalText("333-BIG, hello, 334");
    expect(signals).toEqual([{ key: "333", prediction: "BIG" }]);
    expect(errors).toContain("hello");
    expect(errors).toContain("334");
  });
});

describe("future signal matching — last 3 digits of the period", () => {
  const signals = [
    { key: "333", prediction: "BIG" as const },
    { key: "055", prediction: "SMALL" as const },
  ];

  it("matches on the trailing 3 digits", () => {
    expect(matchSignal("20261002100051333", signals)?.prediction).toBe("BIG");
  });

  it("matches a padded key", () => {
    expect(matchSignal("20261002100050055", signals)?.prediction).toBe("SMALL");
  });

  it("returns null when nothing matches — engine must NOT auto-predict", () => {
    expect(matchSignal("20261002100051777", signals)).toBeNull();
  });
});

describe("step ladder — whole numbers only", () => {
  it("allocates the balance across the selected doubling steps", () => {
    expect(buildSteps(1000, 5)).toEqual([32, 64, 128, 256, 512]);
    expect(buildSteps(1000, 5).reduce((sum, value) => sum + value, 0)).toBeLessThanOrEqual(1000);
    expect(buildSteps(10, 5)).toEqual([0, 0, 0, 0, 0]);
  });
  it("doubles on every loss step and stays integer", () => {
    expect([1, 2, 3, 4, 5].map((s) => stepAmount(10, s))).toEqual([
      10, 20, 40, 80, 160,
    ]);
  });
  it("stays on step 1 after a win (same amount)", () => {
    expect(stepAmount(10, 1)).toBe(10);
  });
});

describe("preview PIN session", () => {
  it("allows the HTTPS dashboard session inside the preview frame", () => {
    expect(pinCookieAttributes(true)).toContain("SameSite=None; Secure; Partitioned");
    expect(pinCookieAttributes(false)).toContain("SameSite=Lax");
  });
});

describe("open-period protection", () => {
  it("never places another bet while a result is pending", () => {
    expect(canPlaceSignalBet("20261002100051333", null, "20261002100051334")).toBe(false);
    expect(canPlaceSignalBet(null, "20261002100051334", "20261002100051334")).toBe(false);
    expect(canPlaceSignalBet(null, "20261002100051333", "20261002100051334")).toBe(true);
  });
});

describe("result sides", () => {
  it("maps digits 5-9 to BIG and 0-4 to SMALL", () => {
    expect(numberToSide(5)).toBe("BIG");
    expect(numberToSide(9)).toBe("BIG");
    expect(numberToSide(4)).toBe("SMALL");
    expect(numberToSide(0)).toBe("SMALL");
  });
});

describe("period progression", () => {
  it("increments 17-digit issue numbers without precision loss", () => {
    expect(nextPeriod("20261002100051550")).toBe("20261002100051551");
  });
});
