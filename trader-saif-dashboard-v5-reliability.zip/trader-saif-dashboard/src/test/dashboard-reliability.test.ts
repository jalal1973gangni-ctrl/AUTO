import { describe, expect, it, vi } from "vitest";

const fixture = vi.hoisted(() => ({ fail: false, hash: "verified-cookie", cached: { server_time: 42, session: null }, rpc: vi.fn(async () => ({ data: false, error: null })) }));
vi.mock("@/integrations/supabase/client.server", () => ({
  supabaseAdmin: {
    rpc: fixture.rpc,
    from: (table: string) => ({ select: () => ({ eq: () => ({ maybeSingle: async () => {
      if (fixture.fail) throw new Error("private database detail");
      return { data: table === "dashboard_settings" ? { pin_hash: fixture.hash } : { state: fixture.cached, cached_at: "2020-01-01T00:00:00Z" }, error: null };
    } }) }) }),
  },
}));
import { handleTick, handleControl, isPinAuthorized } from "@/lib/drx.server";

describe("dashboard failure and viewer coordination", () => {
  it("serves 100 simultaneous viewers from safe cached state when another worker owns the tick", async () => {
    await import("@/integrations/supabase/client.server");
    expect(await isPinAuthorized(new Request("https://dashboard.example", { headers: { cookie: "drx_auth=verified-cookie" } }))).toBe(true);
    const requests = Array.from({ length: 100 }, () => handleTick(new Request("https://dashboard.example/api/public/tick", { method: "POST", headers: { cookie: "drx_auth=verified-cookie" } })));
    const responses = await Promise.all(requests);
    expect(responses).toHaveLength(100);
    for (const response of responses) {
      expect(response.status).toBe(200);
      expect(await response.json()).toEqual({ ok: true, state: fixture.cached });
    }
    expect(fixture.rpc).toHaveBeenCalledTimes(100);
  });
  it("returns a recoverable error instead of crashing when the database fails", async () => {
    fixture.fail = true;
    try {
      const response = await handleControl(new Request("https://dashboard.example/api/public/control", { method: "POST", headers: { cookie: "drx_auth=verified-cookie" }, body: '{}' }));
      expect(response.status).toBe(503);
      expect(await response.text()).not.toContain("private database detail");
    } finally { fixture.fail = false; }
  });
  it("never serves cached account data without the PIN session", async () => {
    const response = await handleTick(new Request("https://dashboard.example/api/public/tick", { method: "POST" }));
    expect(response.status).toBe(401);
    expect(await response.json()).toEqual({ ok: false, unauthorized: true });
  });
});