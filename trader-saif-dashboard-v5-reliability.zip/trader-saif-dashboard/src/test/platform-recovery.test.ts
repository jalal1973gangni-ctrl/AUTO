import { afterEach, describe, expect, it, vi } from "vitest";
import { encryptCredentials, decryptCredentials } from "@/lib/platform-credentials.server";
import { boundedFetch } from "@/lib/platform-http.server";

afterEach(() => vi.unstubAllGlobals());

describe("saved platform credentials", () => {
  it("retains phone and password only as encrypted ciphertext", async () => {
    const value = { phone: "01700000000", password: "test-password-only" };
    const ciphertext = await encryptCredentials(value, "test-encryption-key");
    expect(ciphertext).not.toContain(value.phone);
    expect(ciphertext).not.toContain(value.password);
    expect(await decryptCredentials(ciphertext, "test-encryption-key")).toEqual(value);
    await expect(decryptCredentials(ciphertext, "different-key")).rejects.toThrow();
  });
  it("uses a fresh IV for each saved password", async () => {
    const value = { phone: "01700000000", password: "test-password-only" };
    expect(await encryptCredentials(value, "key")).not.toBe(await encryptCredentials(value, "key"));
  });
});

describe("platform request safety", () => {
  it("attaches a bounded timeout without retrying a bet request", async () => {
    const fetcher = vi.fn().mockRejectedValue(new Error("private provider detail"));
    vi.stubGlobal("fetch", fetcher);
    await expect(boundedFetch("https://platform.example/bet", { method: "POST" })).rejects.toThrow("Platform connection unavailable");
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(fetcher.mock.calls[0]?.[1].signal).toBeInstanceOf(AbortSignal);
  });
});