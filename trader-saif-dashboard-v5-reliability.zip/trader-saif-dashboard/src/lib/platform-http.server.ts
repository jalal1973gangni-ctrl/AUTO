export async function boundedFetch(url: string, init: RequestInit = {}): Promise<Response> {
  try {
    return await fetch(url, { ...init, signal: AbortSignal.timeout(8000) });
  } catch {
    throw new Error("Platform connection unavailable — please retry shortly");
  }
}