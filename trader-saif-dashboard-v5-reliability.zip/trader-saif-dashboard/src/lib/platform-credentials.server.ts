// Server-only authenticated credential storage. Never return plaintext to the UI.
async function key(secret: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encryptCredentials(value: { phone: string; password: string }, secret: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await key(secret), new TextEncoder().encode(JSON.stringify(value))));
  return btoa(String.fromCharCode(...iv, ...ciphertext));
}

export async function decryptCredentials(value: string, secret: string): Promise<{ phone: string; password: string }> {
  const bytes = Uint8Array.from(atob(value), c => c.charCodeAt(0));
  const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv: bytes.slice(0, 12) }, await key(secret), bytes.slice(12));
  const data: unknown = JSON.parse(new TextDecoder().decode(plaintext));
  if (!data || typeof data !== "object" || !("phone" in data) || !("password" in data) || typeof data.phone !== "string" || typeof data.password !== "string") throw new Error("Invalid saved credentials");
  return { phone: data.phone, password: data.password };
}