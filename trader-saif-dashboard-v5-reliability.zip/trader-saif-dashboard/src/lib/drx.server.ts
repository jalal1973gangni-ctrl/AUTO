// Server-only module: platform login APIs, bet engine and dashboard state.
// Load with `await import("@/lib/drx.server")` inside route handlers ONLY —
// never import it from client code.
import { md5 } from "@/lib/md5";
import { boundedFetch } from "./platform-http.server";
import { encryptCredentials, decryptCredentials } from "./platform-credentials.server";
import {
  matchSignal,
  nextPeriod,
  numberToSide,
  parseSignalText,
  stepAmount,
  buildSteps,
  pinCookieAttributes,
  canPlaceSignalBet,
  type Side,
} from "@/lib/engine-logic";
import type {
  ConfigInfo,
  DashboardState,
  EngineMode,
  LogRow,
  Platform,
  ResultRow,
  SessionInfo,
  SignalRow,
} from "@/lib/dashboard.types";

// ── Platform endpoints (port of the verified reference client) ──────────────

const LOTTERY_BASE = "https://api.ar-lottery01.com";
const HISTORY_URL =
  "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json";
const DEVICE_ID = "45de5b6ba3062e1b4827ea21238ffe1a";
const PIN_COOKIE = "drx_auth";

const PLATFORMS: Record<
  Platform,
  { mainBase: string; origin: string; phonetype: number; label: string }
> = {
  dkwin: {
    mainBase: "https://api.dkwinapi.com",
    origin: "https://dkwin16.com",
    phonetype: 1,
    label: "DKWIN",
  },
  hgnice: {
    mainBase: "https://api.hgnicepayapi.com",
    origin: "https://hgnice6.com",
    phonetype: 0,
    label: "HGNICE",
  },
};

/** Public site URL shown in the dashboard iframe — fixed per platform, never saved. */
const SITE_URLS: Record<Platform, string> = {
  dkwin: "https://dkwin16.com",
  hgnice: "https://hgnice6.com",
};

function normalizePlatform(v: unknown): Platform {
  return v === "hgnice" ? "hgnice" : "dkwin";
}

class DrxError extends Error {
  code?: unknown;
  constructor(message: string, code?: unknown) {
    super(message);
    this["code"] = code;
  }
}

// ── Request signing ──────────────────────────────────────────────────────────

function signMain(data: Record<string, unknown>): Record<string, unknown> {
  const d: Record<string, unknown> = { ...data };
  delete d["signature"];
  delete d["timestamp"];
  d["language"] = 0;
  d["random"] = crypto["randomUUID"]()["replace"](/-/g, "");
  const entries = Object["entries"](d)
    ["filter"](
      ([k, v]) =>
        v !== null &&
        v !== undefined &&
        v !== "" &&
        !["signature", "track", "xosoBettingData"]["includes"](k),
    )
    ["sort"](([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  d["signature"] = md5(JSON["stringify"](Object["fromEntries"](entries)))["toUpperCase"]();
  d["timestamp"] = Math["floor"](Date["now"]() / 1000);
  return d;
}

function signLottery(params: Record<string, unknown>): Record<string, unknown> {
  const p: Record<string, unknown> = { ...params };
  delete p["signature"];
  delete p["timestamp"];
  p["random"] = Math["floor"](1e11 + Math["random"]() * 9e11); // 12-digit random
  const entries = Object["entries"](p)
    ["filter"](([, v]) => v !== null && v !== undefined && v !== "")
    ["sort"](([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  p["signature"] = md5(JSON["stringify"](Object["fromEntries"](entries)))["toUpperCase"]();
  p["timestamp"] = Math["floor"](Date["now"]() / 1000);
  return p;
}

function jwtClaims(token: string): Record<string, unknown> | null {
  try {
    const parts = token["split"](".");
    if (parts["length"] < 2) return null;
    const part = parts[1];
    if (!part) return null;
    let payload = part["replace"](/-/g, "+")["replace"](/_/g, "/");
    while (payload["length"] % 4) payload += "=";
    const bin = atob(payload);
    return JSON["parse"](
      new TextDecoder()["decode"](Uint8Array["from"](bin, (c) => c["charCodeAt"](0))),
    );
  } catch {
    return null;
  }
}

// ── HTTP helpers ─────────────────────────────────────────────────────────────

async function jsonFetch(
  url: string,
  init: RequestInit,
): Promise<{ json: Record<string, unknown> | null; res: Response }> {
  const res = await boundedFetch(url, init);
  let json: Record<string, unknown> | null = null;
  try {
    json = await res["json"]();
  } catch {
    throw new DrxError(`API returned non-JSON response (HTTP ${res.status})`);
  }
  // Match the verified fallback client: an HTTP failure is never treated as
  // a successful API response, even if the body happens to contain code=0.
  if (!res.ok) {
    const message = String(json?.["msg"] ?? json?.["message"] ?? `HTTP ${res.status}`);
    throw new DrxError(`Platform request failed (${res.status}): ${message}`, res.status);
  }
  return { json, res };
}

function refreshedToken(res: Response): string | null {
  const auth =
    res["headers"]["get"]("authorization") ?? res["headers"]["get"]("Authorization");
  return auth && auth["startsWith"]("Bearer ") ? auth["slice"](7)["trim"]() : null;
}

async function mainPost(
  endpoint: string,
  token: string | null,
  origin: string,
  payload: Record<string, unknown> = {},
): Promise<Record<string, unknown>> {
  const { json } = await jsonFetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      Accept: "application/json, text/plain, */*",
      "Ar-Origin": origin,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON["stringify"](signMain(payload)),
  });
  if (json?.["code"] !== 0) {
    throw new DrxError(
      String(json?.["msg"] ?? "Main API request failed"),
      json?.["code"],
    );
  }
  return (json["data"] as Record<string, unknown>) ?? {};
}

async function lotteryGet(
  endpoint: string,
  arToken: string,
  params: Record<string, unknown> = {},
): Promise<{
  json: Record<string, unknown> | null;
  newToken: string | null;
}> {
  const signed = signLottery(params);
  const qs = new URLSearchParams();
  for (const [k, v] of Object["entries"](signed)) qs["set"](k, String(v));
  const { json, res } = await jsonFetch(`${endpoint}?${qs.toString()}`, {
    headers: {
      Accept: "application/json, text/plain, */*",
      Authorization: `Bearer ${arToken}`,
    },
  });
  return { json, newToken: refreshedToken(res) };
}

// ── Platform API operations ──────────────────────────────────────────────────

async function transferToGame(
  mainToken: string,
  origin: string,
): Promise<boolean> {
  try {
    await mainPost(
      `${new URL(origin).host === "dkwin16.com" ? "https://api.dkwinapi.com" : "https://api.hgnicepayapi.com"}/api/webapi/Transfer`,
      mainToken,
      origin,
    );
    return true;
  } catch {
    return false;
  }
}

async function warmLotterySession(
  arToken: string,
): Promise<string | null> {
  try {
    const { newToken } = await lotteryGet(
      `${LOTTERY_BASE}/api/Lottery/GetUserInfo`,
      arToken,
      { language: "en" },
    );
    return newToken;
  } catch {
    return null;
  }
}

async function getBalance(
  arToken: string,
): Promise<{ balance: number; newToken: string | null }> {
  const { json, newToken } = await lotteryGet(
    `${LOTTERY_BASE}/api/Lottery/GetBalance`,
    arToken,
    { language: "en" },
  );
  if (json?.["code"] !== 0) {
    throw new DrxError(String(json?.["msg"] ?? "Balance query failed"), json?.["code"]);
  }
  const d = json?.["data"];
  let raw: unknown = d;
  if (d && typeof d === "object" && !Array["isArray"](d)) {
    for (const key of [
      "balance",
      "Balance",
      "money",
      "Money",
      "amount",
      "Amount",
      "userBalance",
      "UserBalance",
      "balanceAmount",
      "BalanceAmount",
    ]) {
      const val = (d as Record<string, unknown>)[key];
      if (val !== null && val !== undefined && val !== "") {
        raw = val;
        break;
      }
    }
  }
  const bal = Number(raw);
  if (!Number.isFinite(bal) || bal < 0 || raw === null || raw === "") throw new DrxError("Platform returned an invalid balance");
  return { balance: bal, newToken };
}

async function placeBet(
  arToken: string,
  period: string,
  side: Side,
  amount: number,
): Promise<void> {
  if (side !== "BIG" && side !== "SMALL") {
    throw new DrxError(`Invalid bet side '${side}'. Only BIG and SMALL are allowed.`);
  }
  if (!/^\d{10,24}$/.test(period)) {
    throw new DrxError("Invalid period — bet was not sent");
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new DrxError("Invalid bet amount — bet was not sent");
  }
  const payload = {
    gameCode: "WinGo_30S",
    issueNumber: period,
    amount: 1,
    // Same whole-taka unit/multiple contract as the untouched fallback ZIP.
    betMultiple: Math["max"](1, Math["round"](amount)),
    betContent: side === "BIG" ? "BigSmall_Big" : "BigSmall_Small",
    language: "en",
  };
  const { json } = await jsonFetch(`${LOTTERY_BASE}/api/Lottery/WinGoBet`, {
    method: "POST",
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json",
      Authorization: `Bearer ${arToken}`,
    },
    body: JSON["stringify"](signLottery(payload)),
  });
  if (json?.["code"] !== 0) {
    throw new DrxError(String(json?.["msg"] ?? "Bet placement failed"), json?.["code"]);
  }
}

async function fetchHistory(pageSize = 10): Promise<ResultRow[]> {
  try {
    const res = await boundedFetch(`${HISTORY_URL}?pageNo=1&pageSize=${pageSize}`, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Cache-Control": "no-cache",
      },
    });
    const payload = await res["json"]();
    const list = payload?.data?.list;
    if (!Array["isArray"](list)) return [];
    return list
      ["filter"](
        (r: Record<string, unknown>) =>
          r && r["issueNumber"] && r["number"] !== undefined && r["number"] !== "",
      )
      ["map"]((r: Record<string, unknown>) => ({
        issueNumber: String(r["issueNumber"]),
        number: String(r["number"]),
        color: String(r["color"] ?? ""),
      }));
  } catch {
    return [];
  }
}

export async function platformLogin(
  platform: Platform,
  phone: string,
  password: string,
): Promise<{
  platform: Platform;
  phone: string;
  account_masked: string;
  main_token: string;
  ar_token: string;
  platform_user_id: string;
  nick_name: string;
  balance: number;
}> {
  const cfg = PLATFORMS[platform];
  const payload = {
    username: phone,
    pwd: password,
    phonetype: cfg["phonetype"],
    logintype: "mobile",
    deviceId: DEVICE_ID,
    packId: "",
    pixelId: "",
    fbcId: "",
    fbc: "",
    fbp: "",
    adId: "",
  };
  const { json } = await jsonFetch(`${cfg.mainBase}/api/webapi/Login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      Accept: "application/json, text/plain, */*",
      "Ar-Origin": cfg["origin"],
    },
    body: JSON["stringify"](signMain(payload)),
  });
  if (json?.["code"] !== 0) {
    throw new DrxError(String(json?.["msg"] ?? "Login failed"), json?.["code"]);
  }
  const d = (json["data"] as Record<string, unknown>) ?? {};
  const mainToken = String(d["token"] ?? "");
  if (!mainToken) throw new DrxError("Login response carried no token");

  const claims = jwtClaims(mainToken) ?? {};
  let userId = String(claims["UserId"] ?? claims["userId"] ?? d["userId"] ?? "");
  const nickName = String(
    claims["NickName"] ?? claims["nickName"] ?? d["nickName"] ?? "",
  );
  const jwtBalance =
    Number(claims["Amount"] ?? claims["amount"] ?? claims["Balance"] ?? claims["balance"]) ||
    0;
  if (!userId && Array["isArray"](d["webSocketChannels"])) {
    for (const ch of d["webSocketChannels"]) {
      if (typeof ch === "string" && ch["includes"]("/userid/")) {
        userId = ch["split"]("/userid/")["pop"]() ?? "";
        break;
      }
    }
  }

  let arToken = "";
  const lotteryUrl = typeof d["lotteryLoginUrl"] === "string" ? d["lotteryLoginUrl"] : "";
  if (lotteryUrl) {
    try {
      arToken = new URL(lotteryUrl)["searchParams"]["get"]("token") ?? "";
    } catch {
      arToken = "";
    }
  }

  await transferToGame(mainToken, cfg["origin"]);
  let currentAr = arToken;
  let live: number | null = null;
  if (currentAr) {
    currentAr = (await warmLotterySession(currentAr)) ?? currentAr;
    try {
      const b = await getBalance(currentAr);
      live = b["balance"];
      currentAr = b["newToken"] ?? currentAr;
    } catch {
      live = null;
    }
  }
  let balance = live ?? jwtBalance;
  if (live !== null && live <= 0 && jwtBalance > 0) balance = jwtBalance;
  if (!currentAr) throw new DrxError("Platform did not open a game session — please retry login");

  return {
    platform,
    phone,
    account_masked: phone["length"] >= 4 ? "****" + phone["slice"](-4) : "****",
    main_token: mainToken,
    ar_token: currentAr,
    platform_user_id: userId,
    nick_name: nickName,
    balance,
  };
}

// ── Database helpers ─────────────────────────────────────────────────────────

let dbModule: Promise<typeof import("@/integrations/supabase/client.server")> | undefined;
async function db() {
  dbModule ??= import("@/integrations/supabase/client.server");
  const { supabaseAdmin } = await dbModule;
  return supabaseAdmin;
}

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto["subtle"]["digest"](
    "SHA-256",
    new TextEncoder()["encode"](text),
  );
  return Array["from"](new Uint8Array(digest))
    ["map"]((b) => b["toString"](16)["padStart"](2, "0"))
    ["join"]("");
}

function readCookie(request: Request, name: string): string | null {
  const cookie = request["headers"]["get"]("cookie") ?? "";
  for (const part of cookie["split"](";")) {
    const idx = part["indexOf"]("=");
    if (idx === -1) continue;
    if (part["slice"](0, idx)["trim"]() === name) return part["slice"](idx + 1)["trim"]();
  }
  return null;
}

function pinCookieHeader(hash: string, secure: boolean): string {
  return `${PIN_COOKIE}=${hash}; ${pinCookieAttributes(secure)}`;
}

export async function pinConfigured(): Promise<boolean> {
  const client = await db();
  const { data } = await client
    ["from"]("dashboard_settings")
    ["select"]("pin_hash")
    ["eq"]("id", 1)
    ["maybeSingle"]();
  return !!data?.pin_hash;
}

export async function isPinAuthorized(request: Request): Promise<boolean> {
  const hash = readCookie(request, PIN_COOKIE);
  if (!hash) return false;
  const client = await db();
  const { data } = await client
    ["from"]("dashboard_settings")
    ["select"]("pin_hash")
    ["eq"]("id", 1)
    ["maybeSingle"]();
  return !!data?.pin_hash && data["pin_hash"] === hash;
}

export async function setupPin(pin: string, secure = true): Promise<string> {
  if (await pinConfigured()) {
    throw new DrxError("PIN already configured");
  }
  const hash = await sha256Hex(pin);
  const client = await db();
  const { error } = await client
    ["from"]("dashboard_settings")
    ["update"]({ pin_hash: hash, updated_at: new Date()["toISOString"]() })
    ["eq"]("id", 1);
  if (error) throw new DrxError(error["message"]);
  return pinCookieHeader(hash, secure);
}

export async function unlockPin(pin: string, secure = true): Promise<string> {
  const client = await db();
  const { data } = await client
    ["from"]("dashboard_settings")
    ["select"]("pin_hash")
    ["eq"]("id", 1)
    ["maybeSingle"]();
  const hash = await sha256Hex(pin);
  if (!data?.pin_hash || data["pin_hash"] !== hash) {
    throw new DrxError("Wrong PIN");
  }
  return pinCookieHeader(hash, secure);
}

// ── Dashboard state ──────────────────────────────────────────────────────────

async function loadConfigRow(client: Awaited<ReturnType<typeof db>>) {
  const { data } = await client
    ["from"]("engine_config")
    ["select"]("*")
    ["eq"]("id", 1)
    ["maybeSingle"]();
  return data as
    | (Record<string, unknown> & {
        session_id: string | null;
        base_amount: number;
        step_count: number;
        target_profit: number;
        starting_balance: number | null;
        running: boolean;
        mode: string;
        current_step: number;
        bet_period: string | null;
        bet_side: string | null;
        bet_amount: number | null;
        bet_step: number | null;
        last_bet_period: string | null;
        stop_reason: string | null;
      })
    | null;
}

export async function getDashboardState(): Promise<DashboardState> {
  const client = await db();
  const [settingsRes, configRow, signalsRes, logsRes] = await Promise["all"]([
    client
      ["from"]("dashboard_settings")
      ["select"]("display_name, iframe_url, pin_hash")
      ["eq"]("id", 1)
      ["maybeSingle"](),
    loadConfigRow(client),
    client
      ["from"]("future_signals")
      ["select"]("period_key, prediction")
      ["order"]("period_key"),
    client
      ["from"]("trade_log")
      ["select"]("*")
      ["order"]("created_at", { ascending: false })
      ["limit"](14),
  ]);

  const settings = settingsRes["data"] as
    | { display_name: string; iframe_url: string; pin_hash: string | null }
    | null;

  let session: SessionInfo | null = null;
  if (configRow?.session_id) {
    const { data } = await client
      ["from"]("platform_sessions")
      ["select"]("*")
      ["eq"]("id", configRow["session_id"])
      ["maybeSingle"]();
    if (data) {
      const s = data as Record<string, unknown>;
      session = {
        platform: normalizePlatform(s["platform"]),
        account_masked: String(s["account_masked"] ?? ""),
        user_id: String(s["platform_user_id"] ?? ""),
        nick_name: String(s["nick_name"] ?? ""),
        balance: Number(s["balance"] ?? 0),
        status: String(s["status"] ?? "active"),
      };
    }
  }

  const history = await fetchHistory(10);
  const latest = history[0] ?? null;

  const config: ConfigInfo | null = configRow
    ? {
        base_amount: Number(configRow["base_amount"]),
        step_count: Number(configRow["step_count"]),
        target_profit: Number(configRow["target_profit"]),
        starting_balance:
          configRow["starting_balance"] == null
            ? null
            : Number(configRow["starting_balance"]),
        running: !!configRow["running"],
        mode: (configRow["mode"] as EngineMode) ?? "auto",
        current_step: Number(configRow["current_step"] ?? 1),
        next_amount: configRow["running"] || configRow["bet_period"]
          ? stepAmount(Number(configRow["base_amount"]), Number(configRow["current_step"] ?? 1))
          : (buildSteps(session?.balance ?? 0, Number(configRow["step_count"]))[0] ?? 0),
        step_amounts: configRow["running"] || configRow["bet_period"]
          ? Array.from({ length: Number(configRow["step_count"]) }, (_, i) => stepAmount(Number(configRow["base_amount"]), i + 1))
          : buildSteps(session?.balance ?? 0, Number(configRow["step_count"])),
        bet_period: configRow["bet_period"],
        bet_side: (configRow["bet_side"] as Side | null) ?? null,
        bet_amount:
          configRow["bet_amount"] == null ? null : Number(configRow["bet_amount"]),
        stop_reason: configRow["stop_reason"],
        target_balance:
          configRow["starting_balance"] == null
            ? null
            : Number(configRow["starting_balance"]) +
              Number(configRow["target_profit"]),
      }
    : null;

  const signals: SignalRow[] = (signalsRes["data"] ?? [])["map"]((s) => ({
    key: (s as { period_key: string })["period_key"],
    prediction: (s as { prediction: string })["prediction"] as Side,
  }));

  const logs: LogRow[] = (logsRes["data"] ?? [])["map"]((l) => {
    const r = l as Record<string, unknown>;
    return {
      id: String(r["id"]),
      period: (r["period"] as string | null) ?? null,
      signal_key: (r["signal_key"] as string | null) ?? null,
      side: (r["side"] as string | null) ?? null,
      amount: r["amount"] == null ? null : Number(r["amount"]),
      step: r["step"] == null ? null : Number(r["step"]),
      result: (r["result"] as string | null) ?? null,
      profit: r["profit"] == null ? null : Number(r["profit"]),
      balance_after:
        r["balance_after"] == null ? null : Number(r["balance_after"]),
      note: String(r["note"] ?? ""),
      created_at: String(r["created_at"] ?? ""),
    };
  });

  return {
    pin_configured: !!settings?.pin_hash,
    display_name: settings?.display_name ?? "TRADER SAIF",
    iframe_url: session ? SITE_URLS[session.platform] : SITE_URLS["dkwin"],
    session,
    config,
    signals,
    logs,
    history,
    current_period: latest ? nextPeriod(latest["issueNumber"]) : null,
    server_time: Date["now"](),
  };
}

// ── Engine loop ──────────────────────────────────────────────────────────────

/**
 * Live balance check against the game wallet. Runs on every tick and right
 * after every bet, then persists to the session so the dashboard always shows
 * the current balance.
 */
async function refreshSessionBalance(
  client: Awaited<ReturnType<typeof db>>,
  session: Record<string, unknown>,
): Promise<number | null> {
  try {
    let b: { balance: number; newToken: string | null };
    try {
      b = await getBalance(String(session["ar_token"] ?? ""));
    } catch {
      // Refresh the game token first; a temporary outage is not a logout.
      const warmed = await warmLotterySession(String(session["ar_token"] ?? ""));
      if (warmed) session["ar_token"] = warmed;
      try {
        b = await getBalance(String(session["ar_token"] ?? ""));
      } catch {
        const { data: saved } = await client.from("platform_credentials").select("ciphertext, recovery_after").eq("session_id", String(session["id"])).maybeSingle();
        if (!saved || Date.parse(saved.recovery_after) > Date.now()) return null;
        const secret = process.env['PLATFORM_CREDENTIAL_SECRET'];
        if (!secret) return null;
        // Cooldown is durable; outages must not repeatedly submit passwords.
        const { data: allowed, error } = await client.from("platform_credentials")
          .update({ recovery_after: new Date(Date.now() + 60000).toISOString() })
          .eq("session_id", String(session["id"])).lte("recovery_after", new Date().toISOString()).select("session_id");
        if (error || !allowed?.length) return null;
        const credentials = await decryptCredentials(saved.ciphertext, secret);
        const info = await platformLogin(normalizePlatform(session["platform"]), credentials.phone, credentials.password);
        const { error: saveError } = await client.from("platform_sessions").update({ main_token: info.main_token, ar_token: info.ar_token }).eq("id", String(session["id"]));
        if (saveError) return null;
        session["main_token"] = info.main_token;
        session["ar_token"] = info.ar_token;
        b = await getBalance(info.ar_token);
      }
    }
    const upd: Record<string, unknown> = {
      balance: b["balance"],
      updated_at: new Date()["toISOString"](),
    };
    if (b["newToken"]) {
      upd["ar_token"] = b["newToken"];
      session["ar_token"] = b["newToken"];
    }
    session["balance"] = b["balance"];
    const { error } = await client
      ["from"]("platform_sessions")
      ["update"](upd as unknown as never)
      ["eq"]("id", String(session["id"]));
    if (error) return null;
    return b["balance"];
  } catch {
    return null; // transient — the next tick retries
  }
}

async function runEngineTick(events: string[]): Promise<void> {
  const client = await db();
  const cfg = await loadConfigRow(client);
  if (!cfg) return;

  const history = await fetchHistory(10);
  const latest = history[0] ?? null;
  const currentPeriod = latest ? nextPeriod(latest["issueNumber"]) : null;

  let session: Record<string, unknown> | null = null;
  if (cfg["session_id"]) {
    const { data } = await client
      ["from"]("platform_sessions")
      ["select"]("*")
      ["eq"]("id", cfg["session_id"])
      ["maybeSingle"]();
    session = (data as Record<string, unknown>) ?? null;
  }

  // 1) Settle an open bet (even when the engine is stopped).
  if (cfg["bet_period"] && session?.["ar_token"]) {
    if (cfg["stop_reason"] === "bet_uncertain") {
      events.push("Bet confirmation unavailable — trading paused; check the platform bet record before continuing");
      return;
    }
    const res = history["find"]((r) => r["issueNumber"] === cfg["bet_period"]);
    if (res) {
      const win = numberToSide(Number(res["number"])) === cfg["bet_side"];
      // Use the pre-bet balance recorded at placement as the PnL baseline;
      // the live balance is refreshed continuously, so the session value is
      // already post-deduction while the bet is open.
      const { data: pendingRow } = await client
        ["from"]("trade_log")
        ["select"]("balance_before")
        ["eq"]("period", cfg["bet_period"])
        ["eq"]("result", "PENDING")
        ["order"]("created_at", { ascending: false })
        ["limit"](1)
        ["maybeSingle"]();
      const pending = (pendingRow ?? null) as Record<string, unknown> | null;
      const prevBalance =
        pending?.["balance_before"] != null
          ? Number(pending["balance_before"])
          : Number(session["balance"] ?? 0);
      const newBalance = await refreshSessionBalance(client, session);
      if (newBalance === null) {
        events.push("Balance temporarily unavailable — keeping the open bet until its balance is verified");
        return;
      }
      const profit = Math["round"]((newBalance - prevBalance) * 100) / 100;

      await client
        ["from"]("trade_log")
        ["update"]({
          result: win ? "WIN" : "LOSS",
          profit,
          balance_after: newBalance,
          note: `Result digit ${res.number} → ${numberToSide(Number(res.number))}`,
        })
        ["eq"]("period", cfg["bet_period"])
        ["eq"]("result", "PENDING");

      const sessionUpdate: Record<string, unknown> = {
        balance: newBalance,
        updated_at: new Date()["toISOString"](),
      };
      await client
        ["from"]("platform_sessions")
        ["update"](sessionUpdate as unknown as never)
        ["eq"]("id", String(session["id"]));

      events["push"](
        win
          ? `WIN — ${cfg.bet_period} ${cfg.bet_side} ৳${cfg.bet_amount} (+৳${profit})`
          : `LOSS — ${cfg.bet_period} ${cfg.bet_side} ৳${cfg.bet_amount} (৳${profit})`,
      );

      const starting =
        cfg["starting_balance"] == null ? null : Number(cfg["starting_balance"]);
      const targetHit =
        starting != null && newBalance >= starting + Number(cfg["target_profit"]);
      let nextStep = win ? 1 : Number(cfg["current_step"]) + 1;
      let stop: string | null = null;
      if (targetHit) stop = "target_reached";
      else if (!win && nextStep > Number(cfg["step_count"]))
        stop = "ladder_exhausted";

      const cfgUpdate: Record<string, unknown> = {
        current_step: stop ? 1 : nextStep,
        bet_period: null,
        bet_side: null,
        bet_amount: null,
        bet_step: null,
        updated_at: new Date()["toISOString"](),
      };
      const ladderBudget = Number(cfg["base_amount"]) * (2 ** Number(cfg["step_count"]) - 1);
      if (win && !stop && newBalance >= ladderBudget + 100) {
        cfgUpdate["base_amount"] = buildSteps(newBalance, Number(cfg["step_count"]))[0] ?? 0;
      }
      if (stop) {
        cfgUpdate["running"] = false;
        cfgUpdate["stop_reason"] = stop;
        events["push"](
          stop === "target_reached"
            ? "🎯 TARGET REACHED — trading stopped."
            : "🛑 STEP LADDER FINISHED — trading stopped.",
        );
      }
      await client["from"]("engine_config")["update"](cfgUpdate as unknown as never)["eq"]("id", 1);
      return; // one engine action per tick
    }
  }

  // 1b) Balance stays live at all times — refresh on every tick.
  if (session && session["status"] !== "expired") {
    if (await refreshSessionBalance(client, session) === null) {
      events.push("Balance temporarily unavailable — reconnecting; no bet sent");
      return;
    }
  }

  // 2) Place the next bet (auto mode, running only).
  if (!cfg["running"] || !session || session["status"] === "expired") return;
  if (!session["ar_token"]) return;
  if (!currentPeriod) return;
  if (!canPlaceSignalBet(cfg["bet_period"], cfg["last_bet_period"], currentPeriod)) return;
  if (cfg["mode"] !== "auto") return;

  const { data: sigRows } = await client
    ["from"]("future_signals")
    ["select"]("period_key, prediction");
  const parsed = (sigRows ?? [])["map"]((s) => ({
    key: (s as { period_key: string })["period_key"],
    prediction: (s as { prediction: string })["prediction"] as Side,
  }));
  const sig = matchSignal(currentPeriod, parsed);
  if (!sig) return; // NO SIGNAL → no bet (never auto-predict)

  // Reference ZIP auto-bet function: WinGo 30S locks bets ~5s before the
  // period ends — never fire inside that window; wait for the next period.
  const secondsLeft = 30 - (Math["floor"](Date["now"]() / 1000) % 30);
  if (secondsLeft <= 6) return;

  const amount = stepAmount(
    Number(cfg["base_amount"]),
    Number(cfg["current_step"]),
  );

  // Reference ZIP behavior: the platform sweeps the game wallet back into the
  // platform wallet when the WinGo page closes — so whenever the game wallet
  // cannot cover the next stake, transfer platform → game wallet first.
  if (amount > Number(session["balance"] ?? 0)) {
    const mainToken = String(session["main_token"] ?? "");
    if (mainToken) {
      await transferToGame(mainToken, SITE_URLS[normalizePlatform(session["platform"])]);
      await refreshSessionBalance(client, session);
    }
  }
  // Still short after the top-up — sit out this period (ZIP auto behavior);
  // the engine keeps running and retries on the next period.
  if (amount > Number(session["balance"] ?? 0)) {
    events["push"](
      `⏳ Balance ৳${Number(session["balance"] ?? 0)} < stake ৳${amount} — waiting, no bet this period.`,
    );
    return;
  }
  // Live pre-bet balance (refreshed earlier this tick) — PnL baseline.
  const balanceBefore = Number(session["balance"] ?? 0);

  // Claim the period before sending money: concurrent ticks must never double-bet.
  const { data: claimed, error: claimError } = await client.from("engine_config")
    .update({ last_bet_period: currentPeriod })
    .eq("id", 1).eq("running", true).is("bet_period", null)
    .or(`last_bet_period.is.null,last_bet_period.neq.${currentPeriod}`)
    .select("id");
  if (claimError) throw new DrxError(claimError.message);
  if (!claimed?.length) return;

  try {
    const { error: pendingError } = await client.from("engine_config").update({ bet_period: currentPeriod, bet_side: sig.prediction, bet_amount: amount, bet_step: Number(cfg.current_step), stop_reason: "bet_uncertain" }).eq("id", 1);
    if (pendingError) throw new DrxError("Could not save bet intent — no bet sent");
    await placeBet(String(session["ar_token"]), currentPeriod, sig["prediction"], amount);
    const { error: logError } = await client["from"]("trade_log")["insert"]({
      period: currentPeriod,
      signal_key: sig["key"],
      side: sig["prediction"],
      amount,
      step: Number(cfg["current_step"]),
      result: "PENDING",
      balance_before: balanceBefore,
      note: "auto signal bet",
    });
    if (logError) throw new Error("Could not save accepted bet confirmation");
    await client
      ["from"]("engine_config")
      ["update"]({
        bet_period: currentPeriod,
        bet_side: sig["prediction"],
        bet_amount: amount,
        bet_step: Number(cfg["current_step"]),
        last_bet_period: currentPeriod,
        stop_reason: null,
        updated_at: new Date()["toISOString"](),
      })
      ["eq"]("id", 1);
    // Balance check right after the bet is accepted.
    const postBet = await refreshSessionBalance(client, session);
    const balText = postBet != null ? ` · balance ৳${postBet}` : "";
    events["push"](
      `BET PLACED — ${currentPeriod} ${sig.prediction} ৳${amount} (step ${cfg.current_step}, signal ${sig.key})${balText}`,
    );
  } catch (e) {
    const msg = (e as Error)["message"] ?? String(e);
    await client["from"]("trade_log")["insert"]({
      period: currentPeriod,
      signal_key: sig["key"],
      side: sig["prediction"],
      amount,
      step: Number(cfg["current_step"]),
      result: null,
      note: `BET FAILED: ${msg}`,
    });
    await client
      ["from"]("engine_config")
      ["update"]({
        last_bet_period: currentPeriod,
        running: false,
        stop_reason: e instanceof DrxError ? "bet_failed" : "bet_uncertain",
        ...(e instanceof DrxError ? { bet_period: null, bet_side: null, bet_amount: null, bet_step: null } : {}),
        updated_at: new Date()["toISOString"](),
      })
      ["eq"]("id", 1);
    events["push"](e instanceof DrxError ? `❌ BET FAILED — ${msg} (trading stopped)` : "Bet confirmation unavailable — trading paused; check the platform bet record; no retry sent");
  }
}

async function tickAction(request: Request): Promise<Response> {
  if (!(await isPinAuthorized(request))) {
    return Response["json"]({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  const events: string[] = [];
  try {
    await runEngineTick(events);
  } catch (e) {
    events["push"](`Engine error: ${(e as Error).message ?? String(e)}`);
  }
  const state = await getDashboardState();
  return Response["json"]({ ok: true, state, events });
}

// ── Control actions ──────────────────────────────────────────────────────────

function intOrNull(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  if (!Number["isFinite"](n) || !Number["isInteger"](n)) return null;
  return n;
}

async function controlAction(request: Request): Promise<Response> {
  if (!(await isPinAuthorized(request))) {
    return Response["json"]({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  const body = (await request["json"]()["catch"](() => ({}))) as Record<string, unknown>;
  const action = String(body["action"] ?? "");
  const client = await db();
  const now = new Date()["toISOString"]();

  try {
    switch (action) {
      case "login": {
        const platform = normalizePlatform(body["platform"]);
        const phone = String(body["phone"] ?? "")["trim"]();
        const password = String(body["password"] ?? "");
        if (!/^\d{6,15}$/["test"](phone)) {
          throw new DrxError("Enter a valid phone/account number (6-15 digits)");
        }
        if (!password) throw new DrxError("Enter the account password");
        if (password.length > 256) throw new DrxError("Password is too long");
        const secret = process.env['PLATFORM_CREDENTIAL_SECRET'];
        if (!secret) throw new DrxError("Secure login storage is unavailable — please retry later");
        const ciphertext = await encryptCredentials({ phone, password }, secret);
        const info = await platformLogin(platform, phone, password);
        const previousCfg = await loadConfigRow(client);
        if (previousCfg?.running || previousCfg?.bet_period) throw new DrxError("Stop trading and wait for the open bet before changing login");
        // Expire previous sessions on the same platform.
        await client
          ["from"]("platform_sessions")
          ["update"]({ status: "expired", updated_at: now })
          ["eq"]("platform", platform)
          ["neq"]("status", "expired");
        const { data: sess, error } = await client
          ["from"]("platform_sessions")
          ["insert"]({
            platform,
            phone,
            account_masked: info["account_masked"],
            main_token: info["main_token"],
            ar_token: info["ar_token"],
            platform_user_id: info["platform_user_id"],
            nick_name: info["nick_name"],
            balance: info["balance"],
            status: "active",
          })
          ["select"]()
          ["single"]();
        if (error) throw new DrxError(error["message"]);
        if (!sess) throw new DrxError("Could not save login");
        const { error: credentialError } = await client.from("platform_credentials").upsert({ session_id: sess.id, ciphertext, recovery_after: now });
        if (credentialError) throw new DrxError("Could not securely save login — retry");
        await client
          ["from"]("engine_config")
          ["update"]({
            session_id: (sess as { id: string })["id"],
            running: false,
            current_step: 1,
            starting_balance: null,
            bet_period: null,
            bet_side: null,
            bet_amount: null,
            bet_step: null,
            last_bet_period: null,
            stop_reason: null,
            updated_at: now,
          })
          ["eq"]("id", 1);
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: [`✅ ${PLATFORMS[platform].label} login successful`],
        });
      }

      case "logout": {
        const cfg = await loadConfigRow(client);
        if (cfg?.bet_period) throw new DrxError("Wait for the open bet result before logging out");
        if (cfg?.session_id) await client.from("platform_credentials").delete().eq("session_id", cfg.session_id);
        await client
          ["from"]("platform_sessions")
          ["update"]({ status: "expired", updated_at: now })
          ["neq"]("status", "expired");
        await client
          ["from"]("engine_config")
          ["update"]({
            session_id: null,
            running: false,
            bet_period: null,
            bet_side: null,
            bet_amount: null,
            bet_step: null,
            last_bet_period: null,
            stop_reason: null,
            updated_at: now,
          })
          ["eq"]("id", 1);
        return Response["json"]({ ok: true, state: await getDashboardState() });
      }

      case "save_config": {
        const cfg = await loadConfigRow(client);
        if (cfg?.running || cfg?.bet_period) throw new DrxError("Stop trading and wait for the open bet before changing settings");
        const upd: Record<string, unknown> = { updated_at: now };
        const steps = intOrNull(body["step_count"]);
        if (steps != null) {
          if (steps < 1 || steps > 50)
            throw new DrxError("Step count must be a whole number 1-50");
          upd["step_count"] = steps;
        }
        const target = intOrNull(body["target_profit"]);
        if (target != null) {
          if (target < 1) throw new DrxError("Target must be a whole number ≥ 1");
          upd["target_profit"] = target;
        }
        if (body["mode"] === "auto" || body["mode"] === "manual") upd["mode"] = body["mode"];
        if (body["display_name"] != null) {
          const name = String(body["display_name"])["trim"]()["slice"](0, 40);
          if (name) upd["display_name"] = name;
        }
        if (body["iframe_url"] != null) {
          upd["iframe_url"] = String(body["iframe_url"])["trim"]()["slice"](0, 500);
        }
        await client["from"]("engine_config")["update"](upd as unknown as never)["eq"]("id", 1);
        await client
          ["from"]("dashboard_settings")
          ["update"]({
            ...(upd["display_name"] ? { display_name: upd["display_name"] } : {}),
            ...("iframe_url" in upd ? { iframe_url: upd["iframe_url"] } : {}),
            updated_at: now,
          } as unknown as never)
          ["eq"]("id", 1);
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: ["⚙️ Settings saved"],
        });
      }

      case "save_signals": {
        const text = String(body["text"] ?? "");
        const { signals, errors } = parseSignalText(text);
        if (signals["length"] > 200) {
          throw new DrxError("Too many signals (max 200)");
        }
        await client["from"]("future_signals")["delete"]()["neq"]("period_key", "");
        if (signals["length"]) {
          const { error } = await client["from"]("future_signals")["insert"](
            signals["map"]((s) => ({ period_key: s["key"], prediction: s["prediction"] })),
          );
          if (error) throw new DrxError(error["message"]);
        }
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: [
            errors["length"]
              ? `📋 Signals saved — ${signals.length} ok, ${errors.length} invalid: ${errors.slice(0, 3).join(", ")}`
              : `📋 Signals saved — ${signals.length} entries`,
          ],
        });
      }

      case "start": {
        const cfg = await loadConfigRow(client);
        if (!cfg?.session_id) throw new DrxError("Login first, then start trading");
        if (cfg.running || cfg.bet_period) throw new DrxError("Trading is running or a bet is awaiting its result");
        const { data: sess } = await client
          ["from"]("platform_sessions")
          ["select"]("*")
          ["eq"]("id", cfg["session_id"])
          ["maybeSingle"]();
        if (!sess || (sess as { status: string })["status"] === "expired") {
          throw new DrxError("Session expired — log in again");
        }
        const activeSession = sess as Record<string, unknown>;
        const liveBalance = await refreshSessionBalance(client, activeSession);
        if (liveBalance == null) throw new DrxError("Balance temporarily unavailable — login retained; retry shortly");
        const base = buildSteps(liveBalance, Number(cfg["step_count"]))[0] ?? 0;
        if (base < 1) throw new DrxError("Balance cannot cover this many steps — reduce STEP");
        const { data: savedSignals } = await client.from("future_signals").select("period_key").limit(1);
        if (!savedSignals?.length) throw new DrxError("Save your signal list before starting");
        const mode: EngineMode = "auto";
        await client
          ["from"]("engine_config")
          ["update"]({
            running: true,
            mode,
            base_amount: base,
            starting_balance: liveBalance,
            current_step: 1,
            stop_reason: null,
            last_bet_period: null,
            bet_period: null,
            bet_side: null,
            bet_amount: null,
            bet_step: null,
            updated_at: now,
          })
          ["eq"]("id", 1);
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: [`🚀 Trading started (${mode === "auto" ? "AUTO signal matching" : "MANUAL"})`],
        });
      }

      case "stop": {
        await client
          ["from"]("engine_config")
          ["update"]({ running: false, stop_reason: null, updated_at: now })
          ["eq"]("id", 1);
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: ["🛑 Trading stopped"],
        });
      }

      case "manual_bet": {
        const side = body["side"] === "BIG" ? "BIG" : body["side"] === "SMALL" ? "SMALL" : null;
        if (!side) throw new DrxError("Choose BIG or SMALL");
        const cfg = await loadConfigRow(client);
        if (!cfg?.session_id) throw new DrxError("Login first");
        if (cfg["bet_period"]) throw new DrxError("A bet is already open for this period");
        const { data: sess } = await client
          ["from"]("platform_sessions")
          ["select"]("*")
          ["eq"]("id", cfg["session_id"])
          ["maybeSingle"]();
        if (!sess || (sess as { status: string })["status"] === "expired") {
          throw new DrxError("Session expired — log in again");
        }
        const s = sess as Record<string, unknown>;
        if (!s["ar_token"]) throw new DrxError("No active game session token");
        // Live balance check before the bet.
        if (await refreshSessionBalance(client, s) === null) throw new DrxError("Balance temporarily unavailable — no bet sent");
        const currentPeriod = (await fetchHistory(1))[0]?.issueNumber;
        if (!currentPeriod) throw new DrxError("Cannot read the current period");
        const period = nextPeriod(currentPeriod);
        const { data: signalRows } = await client.from("future_signals").select("period_key, prediction");
        const signal = matchSignal(period, (signalRows ?? []).map((r) => ({ key: r.period_key, prediction: r.prediction as Side })));
        if (!signal || signal.prediction !== side) throw new DrxError("No matching signal for this period and side");
        if (cfg["last_bet_period"] === period) throw new DrxError("This period already has a bet");
        const amount = stepAmount(Number(cfg["base_amount"]), Number(cfg["current_step"]));
        if (amount > Number(s["balance"] ?? 0)) {
          throw new DrxError("Insufficient balance for this step amount");
        }
        const balanceBefore = Number(s["balance"] ?? 0);
        const { data: claimed, error: claimError } = await client.from("engine_config").update({ last_bet_period: period }).eq("id", 1).is("bet_period", null).or(`last_bet_period.is.null,last_bet_period.neq.${period}`).select("id");
        if (claimError || !claimed?.length) throw new DrxError("This period is already claimed — no duplicate bet sent");
        const { error: intentError } = await client.from("engine_config").update({ bet_period: period, bet_side: side, bet_amount: amount, bet_step: Number(cfg.current_step), stop_reason: "bet_uncertain" }).eq("id", 1);
        if (intentError) throw new DrxError("Could not save bet intent — no bet sent");
        try {
          await placeBet(String(s["ar_token"]), period, side, amount);
        } catch (error) {
          await client.from("engine_config").update({ running: false, stop_reason: error instanceof DrxError ? "bet_failed" : "bet_uncertain", ...(error instanceof DrxError ? { bet_period: null, bet_side: null, bet_amount: null, bet_step: null } : {}) }).eq("id", 1);
          throw new DrxError("Bet not confirmed — trading paused; check the platform bet record; no retry sent");
        }
        // Balance check right after the bet is accepted.
        const postBet = await refreshSessionBalance(client, s);
        const balText = postBet != null ? ` · balance ৳${postBet}` : "";
        await client["from"]("trade_log")["insert"]({
          period,
          signal_key: null,
          side,
          amount,
          step: Number(cfg["current_step"]),
          result: "PENDING",
          balance_before: balanceBefore,
          note: "manual bet",
        });
        await client
          ["from"]("engine_config")
          ["update"]({
            bet_period: period,
            bet_side: side,
            bet_amount: amount,
            bet_step: Number(cfg["current_step"]),
            last_bet_period: period,
            stop_reason: null,
            updated_at: now,
          })
          ["eq"]("id", 1);
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: [`BET PLACED — ${period} ${side} ৳${amount} (manual)${balText}`],
        });
      }

      case "reset": {
        const cfg = await loadConfigRow(client);
        if (cfg?.bet_period) throw new DrxError("Wait for the open bet result before resetting");
        await client
          ["from"]("engine_config")
          ["update"]({
            running: false,
            current_step: 1,
            starting_balance: null,
            stop_reason: null,
            bet_period: null,
            bet_side: null,
            bet_amount: null,
            bet_step: null,
            last_bet_period: null,
            updated_at: now,
          })
          ["eq"]("id", 1);
        return Response["json"]({
          ok: true,
          state: await getDashboardState(),
          events: ["♻️ Engine reset — back to step 1"],
        });
      }

      default:
        return Response["json"](
          { ok: false, error: `Unknown action '${action}'` },
          { status: 400 },
        );
    }
  } catch (e) {
    return Response["json"](
      { ok: false, error: (e as Error)["message"] ?? String(e) },
      { status: 200 },
    );
  }
}

// ── PIN handlers ─────────────────────────────────────────────────────────────

export async function handlePinStatus(): Promise<Response> {
  try {
    return Response["json"]({ configured: await pinConfigured() }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ ok: false, error: "Connection temporarily unavailable — retry shortly" }, { status: 503 });
  }
}

export async function handlePinAction(request: Request): Promise<Response> {
  const body = (await request["json"]()["catch"](() => ({}))) as Record<string, unknown>;
  const pin = String(body["pin"] ?? "");
  if (!/^\d{4,8}$/["test"](pin)) {
    return Response["json"](
      { ok: false, error: "PIN must be 4-8 digits" },
      { status: 200 },
    );
  }
  const action = String(body["action"] ?? "unlock");
  try {
    const secure = new URL(request.url).protocol === "https:" || request.headers.get("x-forwarded-proto") === "https";
    const cookie =
      action === "setup" ? await setupPin(pin, secure) : await unlockPin(pin, secure);
    return new Response(
      JSON["stringify"]({ ok: true, state: await getDashboardState() }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Set-Cookie": cookie,
        },
      },
    );
  } catch (e) {
    return Response["json"](
      { ok: false, error: (e as Error)["message"] ?? String(e) },
      { status: 200 },
    );
  }
}

// One durable lease across all visitors and workers, not an in-memory lock.
// Cache contains only the projected UI state: never tokens, passwords or PINs.
async function coordinatedRequest(request: Request, control: boolean): Promise<Response> {
  let lease: string | null = null;
  try {
    if (!(await isPinAuthorized(request))) return Response.json({ ok: false, unauthorized: true }, { status: 401 });
    const client = await db();
    const { data: runtime, error: readError } = await client.from("dashboard_runtime").select("state, cached_at").eq("id", 1).maybeSingle();
    if (readError) throw readError;
    if (!control && runtime?.state && runtime.cached_at && Date.now() - Date.parse(runtime.cached_at) < 1000) {
      return Response.json({ ok: true, state: runtime.state }, { headers: { "Cache-Control": "no-store" } });
    }
    const token = crypto.randomUUID();
    const { data: claimed, error } = await client.rpc("claim_dashboard_lease", { p_token: token });
    if (error) throw error;
    if (!claimed) {
      if (!control && runtime?.state) return Response.json({ ok: true, state: runtime.state }, { headers: { "Cache-Control": "no-store" } });
      return Response.json({ ok: false, error: "Dashboard is processing another request — retry shortly" }, { status: 409, headers: { "Cache-Control": "no-store", "Retry-After": "2" } });
    }
    lease = token;
    const response = await (control ? controlAction(request) : tickAction(request));
    const result = await response.clone().json() as { state?: DashboardState };
    if (result.state) {
      const { error: cacheError } = await client.from("dashboard_runtime").update({ state: JSON.parse(JSON.stringify(result.state)), cached_at: new Date().toISOString() }).eq("id", 1).eq("lease_token", token);
      if (cacheError) throw cacheError;
    }
    response.headers.set("Cache-Control", "no-store");
    return response;
  } catch {
    return Response.json({ ok: false, error: "Connection temporarily unavailable — login retained; retry shortly" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  } finally {
    if (lease) {
      try {
        const client = await db();
        await client.from("dashboard_runtime").update({ lease_until: null, lease_token: null }).eq("id", 1).eq("lease_token", lease);
      } catch { /* lease expires automatically if the database is unreachable */ }
    }
  }
}

export function handleTick(request: Request) { return coordinatedRequest(request, false); }
export function handleControl(request: Request) { return coordinatedRequest(request, true); }
