// Shared client-safe types for the DRX-TM dashboard API.

export type Platform = "dkwin" | "hgnice";
export type EngineMode = "auto" | "manual";
export type Side = "BIG" | "SMALL";

export interface ResultRow {
  issueNumber: string;
  number: string;
  color: string;
}

export interface SignalRow {
  key: string;
  prediction: Side;
}

export interface LogRow {
  id: string;
  period: string | null;
  signal_key: string | null;
  side: string | null;
  amount: number | null;
  step: number | null;
  result: string | null;
  profit: number | null;
  balance_after: number | null;
  note: string;
  created_at: string;
}

export interface SessionInfo {
  platform: Platform;
  account_masked: string;
  user_id: string;
  nick_name: string;
  balance: number;
  status: string;
}

export interface ConfigInfo {
  base_amount: number;
  step_count: number;
  target_profit: number;
  starting_balance: number | null;
  running: boolean;
  mode: EngineMode;
  current_step: number;
  next_amount: number;
  step_amounts: number[];
  bet_period: string | null;
  bet_side: Side | null;
  bet_amount: number | null;
  stop_reason: string | null;
  target_balance: number | null;
}

export interface DashboardState {
  pin_configured: boolean;
  display_name: string;
  iframe_url: string;
  session: SessionInfo | null;
  config: ConfigInfo | null;
  signals: SignalRow[];
  logs: LogRow[];
  history: ResultRow[];
  current_period: string | null;
  server_time: number;
}

export interface TickResponse {
  ok: boolean;
  state?: DashboardState;
  events?: string[];
  error?: string;
  unauthorized?: boolean;
}
