// Pure engine rules shared by the server engine and the UI. No I/O here.

export type Side = "BIG" | "SMALL";

export interface ParsedSignal {
  key: string; // always exactly 3 digits — the last 3 digits of the period
  prediction: Side;
}

const BIG_WORDS = ["big", "boro", "বড়", "বড়ো", "বড়"];
const SMALL_WORDS = ["small", "choto", "ছোট", "ছোটো", "ছোট"];

/** Map any side word the user may type to BIG / SMALL. */
function toSide(word: string): Side | null {
  const w = word.toLowerCase();
  if (BIG_WORDS.some((b) => w === b || w.startsWith(b))) return "BIG";
  if (SMALL_WORDS.some((s) => w === s || w.startsWith(s))) return "SMALL";
  if (w === "b") return "BIG";
  if (w === "s") return "SMALL";
  return null;
}

const isDigits = (t: string) => /^\d+$/.test(t);

/** Last 3 digits of any period number, zero-padded to exactly 3. */
export function periodKey(digits: string): string {
  return digits.slice(-3).padStart(3, "0");
}

/**
 * Parse a future-signal list in ANY layout the user pastes.
 * Accepted examples: "333-BIG", "333 BIG", "BIG 333", "333b", "334 s",
 * "20261002100051333 small", "333:বড়", comma / newline / space separated.
 * Only the LAST 3 DIGITS of each period and its side are kept; a later
 * duplicate for the same key overrides the earlier one.
 */
export function parseSignalText(text: string): {
  signals: ParsedSignal[];
  errors: string[];
} {
  const errors: string[] = [];
  const map = new Map<string, Side>();

  // Break digit/word joins ("333B" → "333 B"), then drop every separator.
  const norm = text
    .replace(/(\d)(?=[a-zA-Z\u0980-\u09ff])/g, "$1 ")
    .replace(/([a-zA-Z\u0980-\u09ff])(\d)/g, "$1 $2")
    .replace(/[^\w\u0980-\u09ff]+/g, " ");

  const tokens = norm.split(/\s+/).filter(Boolean);

  for (let i = 0; i < tokens.length; i++) {
    const a = tokens[i];
    if (!a) continue;
    const b = tokens[i + 1];
    if (isDigits(a)) {
      const side = b ? toSide(b) : null;
      if (side) {
        map.set(periodKey(a), side);
        i++; // consume the side word
      } else {
        errors.push(a);
      }
      continue;
    }
    const side = toSide(a);
    if (side && b && isDigits(b)) {
      map.set(periodKey(b), side);
      i++; // consume the number
      continue;
    }
    errors.push(a);
  }

  const signals: ParsedSignal[] = [...map.entries()].map(([key, prediction]) => ({
    key,
    prediction,
  }));
  return { signals, errors };
}

/**
 * Match the current period against the future signal list using ONLY the last
 * 3 digits of the period. No match → null, and the engine must never invent a
 * prediction of its own.
 */
export function matchSignal(
  period: string,
  signals: ParsedSignal[],
): ParsedSignal | null {
  const tail = periodKey(period);
  return (
    signals.find((s) => periodKey(s.key) === tail) ?? null
  );
}

/**
 * Step ladder amount: base × 2^(step-1). Whole numbers only — the platform
 * betting uses whole taka, never decimals or points.
 */
export function stepAmount(base: number, step: number): number {
  const cleanBase = Math.max(1, Math.floor(Number(base) || 0));
  const cleanStep = Math.max(1, Math.floor(Number(step) || 1));
  return cleanBase * Math.pow(2, cleanStep - 1);
}

/** Allocate the whole wallet across a doubling ladder without exceeding it. */
export function buildSteps(balance: number, count: number): number[] {
  const steps = Math.min(50, Math.max(1, Math.floor(count) || 1));
  const budget = Math.max(0, Math.floor(balance) || 0);
  const base = Math.floor(budget / (2 ** steps - 1));
  return Array.from({ length: steps }, (_, i) => base * 2 ** i);
}

/** Third-party preview frames need a secure, partitioned session cookie. */
export function pinCookieAttributes(secure: boolean): string {
  return `Path=/; HttpOnly; SameSite=${secure ? "None; Secure; Partitioned" : "Lax"}; Max-Age=${60 * 60 * 24 * 30}`;
}

export function canPlaceSignalBet(openPeriod: unknown, lastPeriod: unknown, period: string): boolean {
  return !openPeriod && lastPeriod !== period;
}

/** WinGo digit result → side: 5-9 BIG, 0-4 SMALL. */
export function numberToSide(n: number): Side {
  return n >= 5 ? "BIG" : "SMALL";
}

/** Next 30s period issue number (sequential digits, safe for 17-digit ids). */
export function nextPeriod(issue: string): string {
  try {
    return (BigInt(issue) + 1n).toString();
  } catch {
    return issue;
  }
}
