import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { buildSteps } from "@/lib/engine-logic";
import type {
  DashboardState,
  Platform,
  Side,
  TickResponse,
} from "@/lib/dashboard.types";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TRADER SAIF — DKWIN & HGNICE Auto Trading Dashboard" },
      {
        name: "description",
        content:
          "DKWIN & HGNICE auto trading dashboard — future signal matching, step ladder betting and live results.",
      },
      {
        property: "og:title",
        content: "TRADER SAIF — DKWIN & HGNICE Auto Trading Dashboard",
      },
      {
        property: "og:description",
        content:
          "DKWIN & HGNICE auto trading dashboard — future signal matching, step ladder betting and live results.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

// ── API helpers ──────────────────────────────────────────────────────────────

async function readApi(res: Response): Promise<TickResponse> {
  if (res.status === 401) return { ok: false, unauthorized: true };
  try { return await res.json() as TickResponse; }
  catch { return { ok: false, error: "Connection temporarily unavailable — retry shortly" }; }
}

async function postControl(body: Record<string, unknown>) {
  const res = await fetch("/api/public/control", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(55000),
  });
  return readApi(res);
}

// ── Page ─────────────────────────────────────────────────────────────────────

function Index() {
  const [state, setState] = useState<DashboardState | null>(null);
  const [locked, setLocked] = useState<boolean | null>(null);
  const shownEvents = useRef(new Set<string>());
  const polling = useRef(false);
  const [connectionError, setConnectionError] = useState("");

  const applyEvents = useCallback((events?: string[]) => {
    for (const ev of events ?? []) {
      if (!shownEvents.current.has(ev)) {
        shownEvents.current.add(ev);
        toast(ev);
      }
    }
    if ((events?.length ?? 0) > 40) shownEvents.current.clear();
  }, []);

  const poll = useCallback(async () => {
    if (polling.current) return;
    polling.current = true;
    try {
      const res = await fetch("/api/public/tick", { method: "POST", signal: AbortSignal.timeout(55000) });
      if (res.status === 401) {
        setLocked(true);
        setConnectionError("");
        return;
      }
      const data = await readApi(res);
      setLocked(false);
      if (data.ok && data.state) {
        setState(data.state);
        setConnectionError("");
        applyEvents(data.events);
      } else {
        setConnectionError(data.error ?? "Connection temporarily unavailable — retrying…");
      }
    } catch {
      setConnectionError("Connection temporarily unavailable — retrying…");
    } finally {
      polling.current = false;
    }
  }, [applyEvents]);

  useEffect(() => {
    // Spread visitors across the one-second engine cadence. Without this small
    // initial jitter, many people opening the dashboard together can create a
    // synchronized burst against the database and lease endpoint.
    const initial = setTimeout(poll, Math.floor(Math.random() * 900));
    const id = setInterval(poll, 1000);
    return () => {
      clearTimeout(initial);
      clearInterval(id);
    };
  }, [poll]);

  if (locked) return <PinGate onUnlocked={poll} />;
  if (!state) return <Shell title={connectionError || "CONNECTING…"} />;

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col gap-3 px-3 py-4">
      <TopBar />
      <NameBar name={state.display_name} />
      {connectionError && <p role="status" className="text-center text-xs text-destructive">{connectionError}</p>}
      {state.session ? (
        <ControlPanel state={state} onChange={setState} applyEvents={applyEvents} poll={poll} />
      ) : (
        <LoginPanel onChange={setState} applyEvents={applyEvents} />
      )}
      <TradeLog state={state} />
      <footer className="pb-4 text-center font-mono text-[10px] text-muted-foreground">
        YOUR LIST ONLY · LAST 3 DIGITS · NO MATCH → NO BET
      </footer>
    </div>
  );
}

// ── PIN gate ─────────────────────────────────────────────────────────────────

function PinGate({ onUnlocked }: { onUnlocked: () => void }) {
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/public/pin")
      .then((r) => r.json())
      .then((d: { configured: boolean }) => setConfigured(d.configured))
      .catch(() => setConfigured(true));
  }, []);

  async function submit() {
    setError("");
    if (!/^\d{4,8}$/.test(pin)) {
      setError("PIN must be 4-8 digits");
      return;
    }
    if (configured === false && pin !== confirmPin) {
      setError("PINs do not match");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/public/pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: configured ? "unlock" : "setup",
          pin,
        }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (data.ok) onUnlocked();
      else setError(data.error ?? "Failed");
    } catch {
      setError("Connection failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm space-y-4 rounded-xl border border-border bg-card p-6">
        <div className="text-center">
          <div className="font-mono text-xl font-bold tracking-widest text-primary">
            TRADER SAIF
          </div>
          <p className="drx-label mt-1">
            {configured ? "ENTER ACCESS PIN" : "SET A NEW ACCESS PIN"}
          </p>
        </div>
        <input
          className="drx-field text-center text-lg tracking-[0.4em]"
          type="password"
          inputMode="numeric"
          placeholder="••••"
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 8))}
        />
        {configured === false && (
          <input
            className="drx-field text-center text-lg tracking-[0.4em]"
            type="password"
            inputMode="numeric"
            placeholder="CONFIRM ••••"
            value={confirmPin}
            onChange={(e) =>
              setConfirmPin(e.target.value.replace(/\D/g, "").slice(0, 8))
            }
          />
        )}
        {error && (
          <p className="text-center text-xs font-semibold text-destructive">{error}</p>
        )}
        <Button
          className="drx-btn bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          disabled={busy || configured === null}
          onClick={submit}
        >
          {configured ? "🔓 UNLOCK" : "🔒 SET PIN"}
        </Button>
      </div>
    </div>
  );
}

// ── Shared chrome ────────────────────────────────────────────────────────────

function Shell({ title }: { title: string }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <p className="font-mono text-sm tracking-widest text-muted-foreground">{title}</p>
    </div>
  );
}

function TopBar() {
  return (
    <div className="flex items-center gap-2">
      <span className="grid h-9 w-9 place-items-center rounded-md border border-border bg-card text-lg text-foreground">
        ≡
      </span>
      <span className="rounded-md border-2 border-primary bg-card px-3 py-1 font-mono text-lg font-bold tracking-widest text-foreground">
        TRADER<span className="text-primary"> SAIF</span>
      </span>
      <span className="ml-auto rounded-md border border-border bg-secondary px-2 py-1 font-mono text-[11px] text-muted-foreground">
        DKWIN16 · HGNICE6
      </span>
    </div>
  );
}

function NameBar({ name }: { name: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-primary/60 bg-primary/15 px-3 py-2">
      <span className="drx-label">NAME</span>
      <span className="font-mono text-sm font-bold tracking-widest text-gold">
        ({name})
      </span>
    </div>
  );
}


// ── Login panel ──────────────────────────────────────────────────────────────

function LoginPanel({
  onChange,
  applyEvents,
}: {
  onChange: (s: DashboardState) => void;
  applyEvents: (e?: string[]) => void;
}) {
  const [platform, setPlatform] = useState<Platform>("dkwin");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function login() {
    setError("");
    setBusy(true);
    try {
      const data = await postControl({
        action: "login",
        platform,
        phone,
        password,
      });
      if (data.unauthorized) return;
      if (data.ok && data.state) {
        onChange(data.state);
        applyEvents(data.events);
      } else {
        setError(data.error ?? "Login failed");
      }
    } catch {
      setError("Connection failed");
    } finally {
      setPassword("");
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3 rounded-lg border border-border bg-card p-4">
      <div>
        <p className="drx-label">
          {platform === "dkwin" ? "DKWIN" : "HGNICE"} SITE
        </p>
        <select
          className="drx-field mt-1"
          value={platform}
          onChange={(e) => setPlatform(e.target.value as Platform)}
        >
          <option value="dkwin">DKWIN — dkwin16.com</option>
          <option value="hgnice">HGNICE — hgnice6.com</option>
        </select>
      </div>
      <div>
        <p className="drx-label">
          {platform === "dkwin" ? "DKWIN" : "HGNICE"} PHONE
        </p>
        <div className="mt-1 flex items-center gap-2 rounded-md border border-input bg-muted/60 px-3">
          <span className="font-mono text-sm text-muted-foreground">+880</span>
          <input
            className="w-full bg-transparent py-2 font-mono text-sm text-foreground outline-none"
            inputMode="numeric"
            placeholder="1XXXXXXXXXX"
            autoComplete="username"
            name="username"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 15))}
          />
        </div>
      </div>
      <div>
        <p className="drx-label">
          {platform === "dkwin" ? "DKWIN" : "HGNICE"} PASS
        </p>
        <input
          className="drx-field mt-1"
          type="password"
          autoComplete="current-password"
          name="password"
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      {error && (
        <p className="text-center text-xs font-semibold text-destructive">{error}</p>
      )}
      <Button
        className="drx-btn bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
        disabled={busy}
        onClick={login}
      >
        🔐 LOGIN {platform === "dkwin" ? "DKWIN" : "HGNICE"}
      </Button>
    </div>
  );
}

// ── Control panel ────────────────────────────────────────────────────────────

function ControlPanel({
  state,
  onChange,
  applyEvents,
  poll,
}: {
  state: DashboardState;
  onChange: (s: DashboardState) => void;
  applyEvents: (e?: string[]) => void;
  poll: () => void;
}) {
  const cfg = state.config;
  const [steps, setSteps] = useState(String(cfg?.step_count ?? 5));
  const [target, setTarget] = useState(String(cfg?.target_profit ?? 100));
  const [signalText, setSignalText] = useState(
    state.signals.map((s) => `${s.key}-${s.prediction}`).join(", "),
  );
  const [busy, setBusy] = useState(false);
  const [seconds, setSeconds] = useState(30 - (Math.floor(Date.now() / 1000) % 30));

  useEffect(() => {
    const id = setInterval(
      () => setSeconds(30 - (Math.floor(Date.now() / 1000) % 30)),
      500,
    );
    return () => clearInterval(id);
  }, []);

  if (!cfg) return null;

  async function act(body: Record<string, unknown>) {
    setBusy(true);
    try {
      const data = await postControl(body);
      if (data.unauthorized) return;
      if (data.ok && data.state) {
        onChange(data.state);
        applyEvents(data.events);
      } else if (data.error) {
        toast.error(data.error);
      }
    } catch {
      toast.error("Connection failed");
    } finally {
      setBusy(false);
    }
  }

  const running = cfg.running;
  const openBet = cfg.bet_period != null;
  const intInput = (v: string) => v.replace(/\D/g, "").slice(0, 7);
  const ladder = running || openBet ? cfg.step_amounts : buildSteps(state.session?.balance ?? 0, Number(steps));

  return (
    <div className="space-y-3 rounded-lg border border-border bg-card p-4">
      {/* Account rows — DRX-TM style */}
      <div className="grid grid-cols-2 gap-2">
        <div className="drx-row">
          <span className="drx-label text-loss">UID</span>
          <span className="font-mono text-sm font-bold text-loss">
            {state.session?.user_id || "—"}
          </span>
        </div>
        <div className="drx-row">
          <span className="drx-label text-primary">BAL</span>
          <span className="font-mono text-sm font-bold text-primary">
            {(state.session?.balance ?? 0).toFixed(2)}
          </span>
        </div>
        <div className="drx-row">
          <span className="drx-label text-gold">TARGET</span>
          <span className="font-mono text-sm font-bold text-gold">
            {cfg.target_profit.toFixed(2)}
          </span>
        </div>
        <div className="drx-row">
          <span className="drx-label text-info">THB</span>
          <span className="font-mono text-sm font-bold text-info">
            {running || openBet ? cfg.next_amount : ladder[0] ?? 0}
          </span>
        </div>
      </div>

      {/* Period + countdown */}
      <div className="drx-row">
        <span className="drx-label">PERIOD</span>
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm text-foreground">
            {state.current_period ?? "—"}
          </span>
          <span
            className={`w-10 rounded px-1 text-center font-mono text-xs font-bold ${seconds <= 5 ? "bg-destructive/30 text-destructive" : "bg-secondary text-muted-foreground"}`}
          >
            {seconds}s
          </span>
        </div>
      </div>

      {/* Engine status */}
      {running ? (
        <div className="rounded-md border border-win/50 bg-win/10 px-3 py-2 text-center font-mono text-xs font-bold tracking-wider text-win">
          ENGINE RUNNING — STEP {cfg.current_step}/{cfg.step_count} ·{" "}
          {cfg.mode === "auto" ? "AUTO SIGNAL MATCH" : "MANUAL"} · NEXT BET ৳
          {cfg.next_amount}
        </div>
      ) : (
        <div className="rounded-md border border-border bg-secondary px-3 py-2 text-center font-mono text-xs text-muted-foreground">
          ENGINE {cfg.stop_reason ? `STOPPED (${cfg.stop_reason.replace(/_/g, " ")})` : "STOPPED"}
        </div>
      )}
      {openBet && (
        <div className="rounded-md border border-gold/60 bg-gold/10 px-3 py-2 text-center font-mono text-xs font-bold text-gold">
          OPEN BET — {cfg.bet_period} {cfg.bet_side} ৳{cfg.bet_amount} · WAITING
          RESULT…
        </div>
      )}

      {/* Config */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <p className="drx-label">STEP</p>
          <input
            className="drx-field mt-1"
            inputMode="numeric"
            disabled={busy || running || openBet}
            value={steps}
            onChange={(e) => setSteps(intInput(e.target.value))}
          />
        </div>
        <div>
          <p className="drx-label">TARGET</p>
          <input
            className="drx-field mt-1"
            inputMode="numeric"
            disabled={busy || running || openBet}
            value={target}
            onChange={(e) => setTarget(intInput(e.target.value))}
          />
        </div>
      </div>
      <div className="space-y-1" aria-label="Step amounts">
        {ladder.map((amount, i) => (
          <div key={i} className={`flex items-center justify-between border-b border-border py-1 font-mono text-xs ${cfg.current_step === i + 1 ? "text-gold" : "text-muted-foreground"}`}>
            <span>STEP {i + 1}</span><span>৳{amount}</span>
          </div>
        ))}
        <div className="flex justify-between font-mono text-xs text-info"><span>TARGET BAL</span><span>৳{((cfg.starting_balance ?? state.session?.balance ?? 0) + Number(target || 0)).toFixed(2)}</span></div>
      </div>
      <Button
        className="w-full rounded-md border border-border bg-secondary py-2 text-xs font-bold tracking-wider text-foreground hover:bg-accent disabled:opacity-50"
        disabled={busy || running || openBet}
        onClick={() =>
          act({ action: "save_config", step_count: steps, target_profit: target })
        }
      >
        💾 SAVE SETTINGS (WHOLE NUMBERS ONLY)
      </Button>

      {/* Signals — auto mode */}
      {(
        <div className="space-y-2 rounded-md border border-border bg-background/40 p-3">
          <p className="drx-label">YOUR LIST — LAST 3 DIGITS ({state.signals.length})</p>
          <textarea
            className="drx-field h-20 resize-none"
            placeholder="333 BIG, 334 SMALL, B 335, 20261002100051333 small …"
            value={signalText}
            onChange={(e) => setSignalText(e.target.value)}
          />
          <div className="flex gap-2">
            <Button
              className="flex-1 rounded-md bg-primary py-2 text-xs font-bold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              disabled={busy}
              onClick={() => act({ action: "save_signals", text: signalText })}
            >
              📋 SAVE SIGNALS
            </Button>
            <Button
              className="rounded-md border border-border bg-secondary px-3 py-2 text-xs font-bold text-muted-foreground hover:bg-accent disabled:opacity-50"
              disabled={busy}
              onClick={() => {
                setSignalText("");
                act({ action: "save_signals", text: "" });
              }}
            >
              CLEAR
            </Button>
          </div>
          <p className="font-mono text-[10px] leading-relaxed text-muted-foreground">
            MATCH RULE: LAST 3 DIGITS OF THE PERIOD → YOUR LIST → BET THAT SIDE.
            NO MATCH = NO BET. ANY FORMAT OK.
          </p>
        </div>
      )}

      {/* Start / stop */}
      {running ? (
        <Button
          className="drx-btn bg-destructive text-destructive-foreground hover:bg-destructive/90 disabled:opacity-50"
          disabled={busy}
          onClick={() => act({ action: "stop" })}
        >
          ⏹ STOP TRADING
        </Button>
      ) : (
        <Button
          className="drx-btn bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          disabled={busy || openBet || ladder[0] === 0 || state.signals.length === 0}
          onClick={() =>
            act({ action: "start", mode: "auto" })
          }
        >
          ▶ START TRADING
        </Button>
      )}

      {/* Session actions */}
      <div className="flex gap-2">
        <Button
          className="flex-1 rounded-md border border-border bg-secondary py-2 text-xs font-bold text-muted-foreground hover:bg-accent disabled:opacity-50"
          disabled={busy}
          onClick={() => act({ action: "reset" })}
        >
          ♻️ RESET STEP
        </Button>
        <Button
          className="flex-1 rounded-md border border-destructive/50 bg-destructive/10 py-2 text-xs font-bold text-destructive hover:bg-destructive/20 disabled:opacity-50"
          disabled={busy}
          onClick={() => {
            act({ action: "logout" });
            setTimeout(poll, 400);
          }}
        >
          ⎋ LOGOUT
        </Button>
      </div>
    </div>
  );
}

// ── Trade log ────────────────────────────────────────────────────────────────

function TradeLog({ state }: { state: DashboardState }) {
  if (!state.logs.length) {
    return (
      <div className="rounded-lg border border-border bg-card p-4 text-center font-mono text-xs text-muted-foreground">
        NO TRADES YET
      </div>
    );
  }
  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="border-b border-border px-3 py-1.5 drx-label">TRADE LOG</div>
      <div className="divide-y divide-border">
        {state.logs.map((l) => (
          <div key={l.id} className="flex items-center gap-2 px-3 py-2 font-mono text-xs">
            <span className="text-muted-foreground">
              {l.period ? `…${l.period.slice(-3)}` : "—"}
            </span>
            <span className={l.side === "BIG" ? "text-loss" : "text-primary"}>
              {l.side ?? "—"}
            </span>
            <span className="text-foreground">৳{l.amount ?? "—"}</span>
            <span className="text-muted-foreground">S{l.step ?? "—"}</span>
            {l.signal_key && (
              <span className="rounded bg-secondary px-1 text-[10px] text-info">
                {l.signal_key}
              </span>
            )}
            <span className="ml-auto">
              {l.result === "WIN" && (
                <span className="text-win">WIN +{l.profit?.toFixed(2)}</span>
              )}
              {l.result === "LOSS" && (
                <span className="text-loss">LOSS {l.profit?.toFixed(2)}</span>
              )}
              {l.result === "PENDING" && <span className="text-gold">PENDING</span>}
              {!l.result && <span className="text-destructive">FAILED</span>}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
