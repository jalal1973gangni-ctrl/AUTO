import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/tick")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const drx = await import("@/lib/drx.server");
        return drx.handleTick(request);
      },
    },
  },
});
