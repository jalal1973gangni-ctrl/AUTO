import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/pin")({
  server: {
    handlers: {
      GET: async () => {
        const drx = await import("@/lib/drx.server");
        return drx.handlePinStatus();
      },
      POST: async ({ request }) => {
        const drx = await import("@/lib/drx.server");
        return drx.handlePinAction(request);
      },
    },
  },
});
