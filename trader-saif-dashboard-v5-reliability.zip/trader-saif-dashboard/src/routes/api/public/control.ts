import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/control")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const drx = await import("@/lib/drx.server");
        return drx.handleControl(request);
      },
    },
  },
});
