export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      dashboard_runtime: {
        Row: {
          cached_at: string | null
          id: number
          lease_token: string | null
          lease_until: string | null
          state: Json | null
        }
        Insert: {
          cached_at?: string | null
          id: number
          lease_token?: string | null
          lease_until?: string | null
          state?: Json | null
        }
        Update: {
          cached_at?: string | null
          id?: number
          lease_token?: string | null
          lease_until?: string | null
          state?: Json | null
        }
        Relationships: []
      }
      dashboard_settings: {
        Row: {
          display_name: string
          id: number
          iframe_url: string
          pin_hash: string | null
          updated_at: string
        }
        Insert: {
          display_name?: string
          id?: number
          iframe_url?: string
          pin_hash?: string | null
          updated_at?: string
        }
        Update: {
          display_name?: string
          id?: number
          iframe_url?: string
          pin_hash?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      engine_config: {
        Row: {
          base_amount: number
          bet_amount: number | null
          bet_period: string | null
          bet_side: string | null
          bet_step: number | null
          current_step: number
          id: number
          last_bet_period: string | null
          mode: string
          running: boolean
          session_id: string | null
          starting_balance: number | null
          step_count: number
          stop_reason: string | null
          target_profit: number
          updated_at: string
        }
        Insert: {
          base_amount?: number
          bet_amount?: number | null
          bet_period?: string | null
          bet_side?: string | null
          bet_step?: number | null
          current_step?: number
          id?: number
          last_bet_period?: string | null
          mode?: string
          running?: boolean
          session_id?: string | null
          starting_balance?: number | null
          step_count?: number
          stop_reason?: string | null
          target_profit?: number
          updated_at?: string
        }
        Update: {
          base_amount?: number
          bet_amount?: number | null
          bet_period?: string | null
          bet_side?: string | null
          bet_step?: number | null
          current_step?: number
          id?: number
          last_bet_period?: string | null
          mode?: string
          running?: boolean
          session_id?: string | null
          starting_balance?: number | null
          step_count?: number
          stop_reason?: string | null
          target_profit?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "engine_config_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "platform_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      future_signals: {
        Row: {
          created_at: string
          id: string
          period_key: string
          prediction: string
        }
        Insert: {
          created_at?: string
          id?: string
          period_key: string
          prediction: string
        }
        Update: {
          created_at?: string
          id?: string
          period_key?: string
          prediction?: string
        }
        Relationships: []
      }
      platform_credentials: {
        Row: {
          ciphertext: string
          recovery_after: string
          session_id: string
        }
        Insert: {
          ciphertext: string
          recovery_after?: string
          session_id: string
        }
        Update: {
          ciphertext?: string
          recovery_after?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "platform_credentials_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "platform_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_sessions: {
        Row: {
          account_masked: string
          ar_token: string | null
          balance: number
          created_at: string
          id: string
          main_token: string | null
          nick_name: string
          phone: string
          platform: string
          platform_user_id: string
          status: string
          updated_at: string
        }
        Insert: {
          account_masked?: string
          ar_token?: string | null
          balance?: number
          created_at?: string
          id?: string
          main_token?: string | null
          nick_name?: string
          phone: string
          platform: string
          platform_user_id?: string
          status?: string
          updated_at?: string
        }
        Update: {
          account_masked?: string
          ar_token?: string | null
          balance?: number
          created_at?: string
          id?: string
          main_token?: string | null
          nick_name?: string
          phone?: string
          platform?: string
          platform_user_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      trade_log: {
        Row: {
          amount: number | null
          balance_after: number | null
          balance_before: number | null
          created_at: string
          id: string
          note: string
          period: string | null
          profit: number | null
          result: string | null
          side: string | null
          signal_key: string | null
          step: number | null
        }
        Insert: {
          amount?: number | null
          balance_after?: number | null
          balance_before?: number | null
          created_at?: string
          id?: string
          note?: string
          period?: string | null
          profit?: number | null
          result?: string | null
          side?: string | null
          signal_key?: string | null
          step?: number | null
        }
        Update: {
          amount?: number | null
          balance_after?: number | null
          balance_before?: number | null
          created_at?: string
          id?: string
          note?: string
          period?: string | null
          profit?: number | null
          result?: string | null
          side?: string | null
          signal_key?: string | null
          step?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_dashboard_lease: { Args: { p_token: string }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
