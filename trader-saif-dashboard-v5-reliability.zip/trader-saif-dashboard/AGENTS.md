<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep wallet ladder allocation in the client-safe engine rules and use it in both the dashboard and server start action so displayed and placed stakes agree.
- Freeze the ladder base while a run is active and rebuild after a winning step when its wallet budget grows by 100, so losses do not shrink the recovery ladder.
- Public dashboard handlers must verify the PIN session; HTTPS PIN cookies are secure and partitioned to support embedded previews.
- Claim each period atomically before automatic placement and block open bets so overlapping ticks cannot duplicate stakes.
- Serialize tick and control actions with a durable database lease and share a one-second sanitized state cache across viewers; process-local locks cannot coordinate multiple workers.
- Store platform login credentials only as AES-GCM ciphertext in service-role-only storage and use a durable recovery cooldown; delete saved credentials on explicit logout.
- Bound external requests, retain sessions on transient failures, never retry uncertain bet submissions, and require a verified balance before placing or settling bets.
