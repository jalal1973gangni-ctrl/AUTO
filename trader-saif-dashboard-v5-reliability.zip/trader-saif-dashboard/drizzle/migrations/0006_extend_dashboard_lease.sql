-- Keep one durable engine owner across all visitors/workers. 180 seconds
-- covers a slow but bounded balance/transfer/bet/result cycle without letting
-- a second worker take over while the first request is still active.
CREATE OR REPLACE FUNCTION public.claim_dashboard_lease(p_token uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.dashboard_runtime(id) VALUES (1) ON CONFLICT DO NOTHING;
  UPDATE public.dashboard_runtime
     SET lease_token = p_token, lease_until = now() + interval '180 seconds'
   WHERE id = 1 AND (lease_until IS NULL OR lease_until < now());
  RETURN FOUND;
END;
$$;
REVOKE ALL ON FUNCTION public.claim_dashboard_lease(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_dashboard_lease(uuid) TO service_role;
