CREATE TABLE public.dashboard_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  pin_hash text,
  display_name text NOT NULL DEFAULT 'AURA SAIF',
  iframe_url text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.platform_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL CHECK (platform IN ('drx', 'hgnice')),
  phone text NOT NULL,
  account_masked text NOT NULL DEFAULT '',
  main_token text,
  ar_token text,
  platform_user_id text NOT NULL DEFAULT '',
  nick_name text NOT NULL DEFAULT '',
  balance numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.engine_config (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  session_id uuid REFERENCES public.platform_sessions(id) ON DELETE SET NULL,
  base_amount integer NOT NULL DEFAULT 10 CHECK (base_amount >= 1),
  step_count integer NOT NULL DEFAULT 5 CHECK (step_count >= 1 AND step_count <= 50),
  target_profit integer NOT NULL DEFAULT 100 CHECK (target_profit >= 1),
  starting_balance numeric,
  running boolean NOT NULL DEFAULT false,
  mode text NOT NULL DEFAULT 'auto' CHECK (mode IN ('auto', 'manual')),
  current_step integer NOT NULL DEFAULT 1 CHECK (current_step >= 1),
  bet_period text,
  bet_side text CHECK (bet_side IN ('BIG', 'SMALL')),
  bet_amount integer,
  bet_step integer,
  last_bet_period text,
  stop_reason text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.future_signals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_key text NOT NULL UNIQUE,
  prediction text NOT NULL CHECK (prediction IN ('BIG', 'SMALL')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.trade_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period text,
  signal_key text,
  side text CHECK (side IN ('BIG', 'SMALL')),
  amount numeric,
  step integer,
  result text CHECK (result IN ('PENDING', 'WIN', 'LOSS')),
  profit numeric,
  balance_after numeric,
  note text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.dashboard_settings TO service_role;
GRANT ALL ON public.platform_sessions TO service_role;
GRANT ALL ON public.engine_config TO service_role;
GRANT ALL ON public.future_signals TO service_role;
GRANT ALL ON public.trade_log TO service_role;

ALTER TABLE public.dashboard_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.engine_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.future_signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trade_log ENABLE ROW LEVEL SECURITY;

INSERT INTO public.dashboard_settings (id) VALUES (1) ON CONFLICT DO NOTHING;
INSERT INTO public.engine_config (id) VALUES (1) ON CONFLICT DO NOTHING;