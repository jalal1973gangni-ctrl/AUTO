CREATE TABLE public.platform_credentials (session_id uuid PRIMARY KEY REFERENCES public.platform_sessions(id) ON DELETE CASCADE, ciphertext text NOT NULL, recovery_after timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.platform_credentials TO service_role;
ALTER TABLE public.platform_credentials ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.dashboard_runtime (id integer PRIMARY KEY CHECK (id = 1), state jsonb, cached_at timestamptz, lease_token uuid, lease_until timestamptz);
GRANT ALL ON public.dashboard_runtime TO service_role;
ALTER TABLE public.dashboard_runtime ENABLE ROW LEVEL SECURITY;
CREATE FUNCTION public.claim_dashboard_lease(p_token uuid) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 INSERT INTO public.dashboard_runtime(id) VALUES (1) ON CONFLICT DO NOTHING;
 UPDATE public.dashboard_runtime SET lease_token = p_token, lease_until = now() + interval '60 seconds' WHERE id = 1 AND (lease_until IS NULL OR lease_until < now());
 RETURN FOUND;
END; $$;
REVOKE ALL ON FUNCTION public.claim_dashboard_lease(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_dashboard_lease(uuid) TO service_role;