# TRADER SAIF dashboard

## Updated dashboard

- BAL shows the game wallet balance; TARGET remains the profit goal.
- STEP and balance determine the whole-taka doubling ladder. QTY is no longer an input.
- Bets require a saved signal matching the current period's last three digits. No generated predictions.
- HTTPS PIN sessions support embedded previews. Automatic bets claim the period before placement to prevent duplicate ticks.
- Platform phone/password are encrypted server-side for reconnecting; explicit logout removes saved credentials. Existing logins must sign in once to enable recovery.
- A shared one-second state cache and 180-second database lease keep concurrent visitors/workers from duplicating platform calls. Bet placement validates period, side and amount; HTTP failures are rejected even if the response body looks successful. External requests time out and return recoverable errors. No automatic retry of an uncertain bet submission.
- The engine never generates its own signal. It only matches saved future-signal entries; no matching signal means no bet. The untouched DKWIN fallback archive is the reference for the WinGoBet payload/signing contract.

## Source archive setup

This archive excludes credentials, repository metadata, installed dependencies and generated build output. Connect it to Lovable Cloud and configure environment values through the project settings; never put private keys into source code. Apply the included database migrations to a new database, or apply only outstanding migrations to an existing database. Existing deployments must also apply migration `0006_extend_dashboard_lease.sql` to extend the shared engine lease to 180 seconds. Existing PINs and platform sessions are not included.
Generate a private random `PLATFORM_CREDENTIAL_SECRET` (at least 64 characters) in the hosting secret settings before login; retain the same value to decrypt saved credentials. The current project's secret is configured but is not included in this ZIP. Publish the app to deploy the updated secret and code to the live site. This is one shared PIN-protected dashboard/account, not 100 independent trading accounts. A 100-person live authenticated load test and real-money bet acceptance are not verified; no deployment can guarantee zero outages.

Run `bun install`, then `bun run dev`. Run `bun run test` for the rule checks. Unlock the dashboard with your PIN, log in to the platform, save STEP/TARGET and your signal list, then start. A wallet too small for the selected ladder prevents starting. Live platform placement still requires verification using your own logged-in dashboard; the source checks do not prove an external platform accepted a bet.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
